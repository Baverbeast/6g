module DiffList
type 'a dlist = 'a list -> 'a list


let fromList : 'a list -> 'a dlist = (@)
let toList (dl : 'a dlist) : 'a list = dl []
let nil : 'a dlist = fun ys -> ys // = fromList []
let cons (x : 'a, dl : 'a dlist) : 'a dlist = fun ys -> x :: dl ys
let append : 'a dlist -> 'a dlist -> 'a dlist = (<<)

type BTree<'a> =
    | Empty
    | Node of 'a * BTree<'a> * BTree<'a>

let rec inorderD (tree: BTree<'a>) : 'a dlist =
    match tree with
    | Empty -> nil
    | Node (value, left, right) ->
        inorderD left << fromList [value] << inorderD right


let inorder (tree:BTree<'a>) : 'a list = 
    (toList<<inorderD)tree




