module Btree

type BTree<'a> =
    | Empty
    | Branch of BTree<'a> * 'a * BTree<'a>

let rec size (tree: BTree<'a>) : int =
    match tree with
    | Empty -> 0  
    | Branch (left, _ , right) ->  size left + 1 + size right

let rec fold a i tree = 
    match tree with
        | Empty -> i
        | Branch (left, x, right) ->
            let sizeLeft = fold a i left
            let sizeRight = fold a i right 
            a (sizeLeft,x,sizeRight)




    


