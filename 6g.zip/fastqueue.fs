﻿module FastQueue
type Queue<'a> = 'a list * 'a list
let emptyQueue = ([], [])

let enqueue ((frontq , endq), x) =  (frontq , x :: endq) 

let rec dequeue (frontq , endq) = //runtime error på denne funktion da når både frontq og endq er tomme kører den uendeligt uden stop.
    match frontq with
    | [] -> dequeue (List.rev endq, [])
    | x :: xs -> Some (x ,(xs, endq))

let fromList xs = (xs, [])

let toList (frontq, endq) = frontq @ List.rev endq
